
=== ROMANICA (Regular) ===
=== ROMANICA ITALIC ===
=== ROMANICA BOLD ===
=== ROMANICA BOLD ITALIC ===

=== ROMANICA LIGHT ===
=== ROMANICA LIGHT ITALIC ===

=== ROMANICA MEDIUM ===
=== ROMANICA MEDIUM ITALIC ===



Keith Bates / K-Type © 2017 (version 1.0)
www.k-type.com    -    info@k-type.com

ROMANICA is a relaxed humanist sans with subtly curved corners and slightly flared glyphic terminals that are expressively angled where appropriate. Romanica has the authority of the ages without the harshness of many classically inspired typefaces.

ROMANICA is available in three packages - 
• Basic Family (Regular, Italic, Bold & Bold Italic)
• Light (Light & Light Italic)
• Medium (Medium & Medium Italic)

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------